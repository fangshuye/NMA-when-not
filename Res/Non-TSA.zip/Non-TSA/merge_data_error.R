#setwd("~/Desktop/research/Meta-Analysis/NMA/res/V13/Error")
# setwd("C:/Users/fye/OneDrive - Iowa State University/Research/NMA/res/V17/dep")
setwd('/Users/fangshu/OneDrive\ -\ Iowa\ State\ University/Research/Project_II_When_not/Res/Non-TSA/V20')

alldata_1 <- c()
for (r in 1:4) {
  dat <- read.csv(paste0("res_error_prev_dep_row_",r,".csv"),header = T)
  alldata_1 <- rbind(alldata_1,dat)
}

#write.csv(alldata,'res_error_nma_V15.csv',row.names = F)

alldata_2 <- c()
for (r in 1:4) {
  dat <- read.csv(paste0("res_error_single_dep_row_",r,".csv"),header = T)
  alldata_2 <- rbind(alldata_2,dat)
}


# alldata_3 <- c()
# for (r in 1:4) {
#   dat <- read.csv(paste0("res_error_single_indep_row_",r,".csv"),header = T)
#   alldata_3 <- rbind(alldata_3,dat)
# }

#write.csv(alldata,'res_error_single_V13.csv',row.names = F)


#rm(list = ls())
#dat1 <- read.csv('res_error_net_V13.csv',header = T)
#dat2 <- read.csv("res_error_single_V13.csv",header = T)

# dat_all <- cbind(dat1,dat2[,5:7])
# colnames(dat_all)[5:7] <- c("power1","bias1","se1")
# colnames(dat_all)[8:10] <- c("power2","bias2","se2")
# dat_all$sample_size <- paste0("(",dat_all$n1,",",dat_all$n2,")")
# dat_all <- dat_all[,c(1:2,11,5:10)]
# write.csv(dat_all,'./V5/summary_data.csv',row.names = F)

dat_all <- cbind(alldata_1[,-7],alldata_2[,4:6])
colnames(dat_all)[4:6] <- c("type_I_error_1","bias1","se_1")
colnames(dat_all)[7:9] <- c("type_I_error_2","bias2","se_2")
write.csv(dat_all,'summary_data_error_dep_V20.csv',row.names = F)

###################### indep #############################

setwd('/Users/fangshu/OneDrive\ -\ Iowa\ State\ University/Research/NMA/res/V19')
# setwd("C:/Users/fye/OneDrive - Iowa State University/Research/NMA/res/V17/indep")

alldata_1 <- c()
for (r in 1:4) {
  dat <- read.csv(paste0("res_error_prev_indep_row_",r,".csv"),header = T)
  alldata_1 <- rbind(alldata_1,dat)
}


alldata_2 <- c()
for (r in 1:4) {
  dat <- read.csv(paste0("res_error_single_indep_row_",r,".csv"),header = T)
  alldata_2 <- rbind(alldata_2,dat)
}

dat_all <- cbind(alldata_1[,-7],alldata_2[,4:6])
colnames(dat_all)[4:6] <- c("type_I_error_1","bias1","se_1")
colnames(dat_all)[7:9] <- c("type_I_error_2","bias2","se_2")
write.csv(dat_all,'summary_data_error_indep_V19.csv',row.names = F)




